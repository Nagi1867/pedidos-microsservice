package com.example.notificacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
